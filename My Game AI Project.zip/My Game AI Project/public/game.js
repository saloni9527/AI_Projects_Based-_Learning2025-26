// Prolog Adventure — Worlds & Multi-Levels
// Save this as js/game.js

document.addEventListener('DOMContentLoaded', () => {

  // ---------- DOM ----------
  const canvas = document.getElementById('gameCanvas');
  if(!canvas){ console.error('Canvas not found'); return; }
  const ctx = canvas.getContext('2d');

  const startBtn = document.getElementById('startBtn');
  const pauseBtn = document.getElementById('pauseBtn');
  const stopBtn = document.getElementById('stopBtn');
  const worldBtns = document.querySelectorAll('.worldBtn');

  const scoreEl = document.getElementById('score');
  const worldNameEl = document.getElementById('worldDisplay');
  const levelEl = document.getElementById('levelDisplay');
  const levelProgressInner = document.getElementById('levelProgressInner');
  const levelNotice = document.getElementById('levelNotice');
  const highscoreEl = document.getElementById('highscore');
  const activePowerEl = document.getElementById('activePower');
  const heartsEl = document.getElementById('hearts');

  const leftBtn = document.getElementById('leftBtn');
  const rightBtn = document.getElementById('rightBtn');
  const jumpBtn = document.getElementById('jumpBtn');

  const menuOverlay = document.getElementById('menuOverlay');
  const overlayStart = document.getElementById('overlayStart');
  const overlayResume = document.getElementById('overlayResume');
  const gameOverOverlay = document.getElementById('gameOverOverlay');
  const restartBtn = document.getElementById('restartBtn');
  const closeOverlay = document.getElementById('closeOverlay');
  const finalScore = document.getElementById('finalScore');

  // ---------- Audio ----------
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  const audioCtx = AudioCtx ? new AudioCtx() : null;
  let musicInterval = null;
  function beep(freq=440, dur=0.08, type='sine', vol=0.08){
    if(!audioCtx) return;
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = type; o.frequency.value = freq;
    g.gain.value = vol;
    o.connect(g); g.connect(audioCtx.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + dur);
    o.stop(audioCtx.currentTime + dur + 0.02);
  }
  const soundCoin = ()=> beep(1000,0.06,'square',0.09);
  const soundJump = ()=> beep(420,0.09,'sawtooth',0.08);
  const soundHit = ()=> beep(120,0.15,'sine',0.12);
  const soundPower = ()=> beep(720,0.12,'triangle',0.09);
  const soundLevelUp = ()=> { beep(880,0.08,'sine',0.08); setTimeout(()=>beep(1100,0.07,'sine',0.06),120); };

  // ---------- Worlds & Levels config ----------
  // Each world has name, colors, enemy color/base speed, music token
  const worlds = [
    { name:'Forest', bg1:'#dfffe0', bg2:'#b9f7c4', enemyColor:'#2e7d32', enemySpeed:0.9, music:'forest' },
    { name:'Desert', bg1:'#fff4d1', bg2:'#ffd18f', enemyColor:'#a0522d', enemySpeed:1.4, music:'desert' },
    { name:'Snow',   bg1:'#eaf6ff', bg2:'#dfeffd', enemyColor:'#4a90e2', enemySpeed:0.8, music:'snow' },
    { name:'Space',  bg1:'#0b1220', bg2:'#1b2a47', enemyColor:'#ff4081', enemySpeed:1.8, music:'space' }
  ];
  const MAX_LEVEL = 5;
  // Score thresholds for level-up per level (multiplied by world factor)
  const BASE_LEVEL_THRESHOLDS = [0, 150, 450, 900, 1600, 2600]; // index = level

  // ---------- State ----------
  let currentWorld = 0;
  let running = false, paused = false;
  let lastTimestamp = 0, spawnTimer = 0, frames = 0;

  const groundY = 420;
  let player = { x:50, y:groundY, width:48, height:48, vy:0, onGround:true, bob:0 };

  let baseSpeed = 3, speed = 3;
  let score = 0, highscore = Number(localStorage.getItem('pa_highscore') || 0);
  let lives = 3, maxLives = 3;

  // levels per world (track progress separately)
  let worldLevels = [1,1,1,1]; // initial level 1 for each world
  let worldProgress = [0,0,0,0]; // progress toward next level
  function currentLevel(){ return worldLevels[currentWorld]; }
  function currentProgress(){ return worldProgress[currentWorld]; }

  // Entities
  let obstacles = [], coins = [], enemies = [], powerups = [], projectiles = [];
  let activePower = null; // {type,expires}
  const powerDuration = { shield:6000, speed:5000, double:7000 };

  // ---------- UI helpers ----------
  function updateUI(){
    if(scoreEl) scoreEl.textContent = Math.floor(score);
    if(worldNameEl) worldNameEl.textContent = worlds[currentWorld].name;
    if(levelEl) levelEl.textContent = currentLevel();
    if(highscoreEl) highscoreEl.textContent = highscore;
    if(activePowerEl) activePowerEl.textContent = activePower ? `${activePower.type} (${Math.max(0,Math.ceil((activePower.expires-performance.now())/1000))}s)` : 'None';
    // hearts
    if(heartsEl){
      heartsEl.innerHTML = '';
      for(let i=0;i<maxLives;i++){
        const d = document.createElement('div');
        d.className = 'heart' + (i < lives ? ' full' : '');
        heartsEl.appendChild(d);
      }
    }
    // level progress bar
    const lvl = currentLevel();
    const threshold = getLevelThreshold(lvl);
    const prog = worldProgress[currentWorld];
    const pct = Math.min(100, Math.round((prog / threshold) * 100));
    if(levelProgressInner) levelProgressInner.style.width = pct + '%';
  }

  // ---------- Utilities ----------
  function rand(min,max){ return Math.random()*(max-min)+min; }
  function rectsCollide(a,b){ return !(a.x + a.width < b.x || a.x > b.x + b.width || a.y + a.height < b.y || a.y > b.y + b.height); }
  function circleRectCollide(cx,cy,r,rect){
    const distX = Math.abs(cx - (rect.x + rect.width/2));
    const distY = Math.abs(cy - (rect.y + rect.height/2));
    if (distX > (rect.width/2 + r)) return false;
    if (distY > (rect.height/2 + r)) return false;
    if (distX <= (rect.width/2)) return true;
    if (distY <= (rect.height/2)) return true;
    const dx = distX - rect.width/2, dy = distY - rect.height/2;
    return (dx*dx + dy*dy <= r*r);
  }

  // ---------- Level logic ----------
  function getLevelThreshold(level){
    // base thresholds scaled slightly by world index (space harder)
    const base = BASE_LEVEL_THRESHOLDS[level] || BASE_LEVEL_THRESHOLDS[BASE_LEVEL_THRESHOLDS.length-1];
    return Math.round(base * (1 + currentWorld*0.18));
  }

  function addProgress(amount){
    worldProgress[currentWorld] += amount;
    const lvl = currentLevel();
    const threshold = getLevelThreshold(lvl);
    if(worldProgress[currentWorld] >= threshold && lvl < MAX_LEVEL){
      // level up
      worldLevels[currentWorld] = Math.min(MAX_LEVEL, lvl + 1);
      worldProgress[currentWorld] = 0;
      levelUpEffect();
      // increase base speed slightly
      baseSpeed += 0.6;
      speed = baseSpeed + worlds[currentWorld].enemySpeed * 0.5;
    } else if(worldProgress[currentWorld] >= threshold && lvl >= MAX_LEVEL){
      // reached max level — trigger boss spawn if not present
      spawnBossIfNeeded();
    }
  }

  function levelUpEffect(){
    if(levelNotice){
      levelNotice.style.display = 'block';
      setTimeout(()=> levelNotice.style.display = 'none', 1300);
    }
    soundLevelUp();
  }

  // ---------- Spawning ----------
  function spawnObstacle(){ const h=rand(30,84), w=rand(28,90); obstacles.push({ x:canvas.width+20, y:groundY + (player.height - h), width:w, height:h }); }
  function spawnCoin(){ const r=10, y=rand(groundY-120, groundY-30); coins.push({ x:canvas.width+30, y, r }); }
  function spawnEnemy(){ const w=44,h=44,y=groundY; const cfg = worlds[currentWorld]; enemies.push({ x:canvas.width+30, y, width:w, height:h, speed: cfg.enemySpeed * (0.8 + Math.random()*0.8) }); }
  function spawnPowerup(){ const types=['shield','speed','double']; const type=types[Math.floor(Math.random()*types.length)]; const y=rand(groundY-140, groundY-40); powerups.push({ x:canvas.width+30, y, type, ttl:12000 }); }

  // Boss (Level 5)
  let boss = null;
  function spawnBossIfNeeded(){
    if(boss) return;
    // spawn a boss unique per world
    const w = 150, h = 120;
    boss = { x: canvas.width + 80, y: groundY - (h - player.height), width:w, height:h, hp:20 + currentWorld*10, phase:0, shootTimer:0 };
  }
  function updateBoss(dt){
    if(!boss) return;
    // boss moves slowly leftwards then hovers
    boss.x -= 0.3 * (1 + currentWorld*0.2);
    if(boss.x < canvas.width - 320) boss.x = canvas.width - 320;
    // shooting
    boss.shootTimer -= dt;
    if(boss.shootTimer <= 0){
      boss.shootTimer = 900 - currentWorld*80;
      // spawn projectiles aimed at player
      for(let i=0;i<3;i++){
        const angle = Math.atan2((player.y - boss.y), (player.x - boss.x)) + (rand(-0.5,0.5));
        projectiles.push({ x: boss.x, y: boss.y + boss.height/2, vx: Math.cos(angle)*4, vy: Math.sin(angle)*4, r:6 });
      }
    }
  }

  // ---------- Power handling ----------
  function applyPower(type){
    activePower = { type, expires: performance.now() + (powerDuration[type]||5000) };
    soundPower();
    if(type === 'speed') speed *= 1.8;
  }
  function clearPower(){
    if(!activePower) return;
    if(activePower.type === 'speed') speed = baseSpeed + worlds[currentWorld].enemySpeed * 0.5;
    activePower = null;
  }

  // ---------- Reset/Start/Stop/Pause ----------
  function resetAll(){
    running = false; paused = false; lastTimestamp = 0; spawnTimer = 0; frames = 0;
    obstacles = []; coins = []; enemies = []; powerups = []; projectiles = [];
    boss = null; activePower = null;
    score = 0; lives = maxLives;
    player.x = 50; player.y = groundY; player.vy = 0; player.onGround = true; player.bob = 0;
    baseSpeed = 3; speed = baseSpeed + worlds[currentWorld].enemySpeed * 0.5;
    // ensure UI shows correct starting world & level
    if(canvas) canvas.style.background = createWorldBackground(currentWorld);
    updateUI();
  }

  function startGame(){
    if(audioCtx) try{ audioCtx.resume(); }catch(e){}
    resetAll();
    running = true; paused = false;
    if(menuOverlay) menuOverlay.style.display = 'none';
    if(gameOverOverlay) gameOverOverlay.style.display = 'none';
    startWorldMusic();
    lastTimestamp = performance.now();
    requestAnimationFrame(loop);
  }

  function stopGame(){
    running = false; paused = false; clearPower();
    stopWorldMusic();
    if(menuOverlay) menuOverlay.style.display = 'flex';
    updateUI();
  }

  function togglePause(){
    if(!running) return;
    paused = !paused;
    if(pauseBtn) pauseBtn.textContent = paused ? 'Resume' : 'Pause';
    if(!paused){ lastTimestamp = performance.now(); requestAnimationFrame(loop); }
  }

  // ---------- Highscore ----------
  function saveHighscore(){ if(Math.floor(score) > highscore){ highscore = Math.floor(score); localStorage.setItem('pa_highscore', highscore); } }

  // ---------- Input ----------
  let input = { left:false, right:false, jump:false };
  document.addEventListener('keydown', (e)=>{
    if(e.key==='ArrowLeft' || e.key==='a') input.left = true;
    if(e.key==='ArrowRight' || e.key==='d') input.right = true;
    if(e.key===' ' || e.key==='ArrowUp' || e.key==='w'){ input.jump = true; tryJump(); e.preventDefault(); }
  });
  document.addEventListener('keyup', (e)=>{
    if(e.key==='ArrowLeft' || e.key==='a') input.left = false;
    if(e.key==='ArrowRight' || e.key==='d') input.right = false;
    if(e.key===' ' || e.key==='ArrowUp' || e.key==='w') input.jump = false;
  });
  if(leftBtn){ leftBtn.addEventListener('mousedown', ()=> input.left = true); leftBtn.addEventListener('mouseup', ()=> input.left = false); leftBtn.addEventListener('touchstart', ()=> input.left = true); leftBtn.addEventListener('touchend', ()=> input.left = false); }
  if(rightBtn){ rightBtn.addEventListener('mousedown', ()=> input.right = true); rightBtn.addEventListener('mouseup', ()=> input.right = false); rightBtn.addEventListener('touchstart', ()=> input.right = true); rightBtn.addEventListener('touchend', ()=> input.right = false); }
  if(jumpBtn) jumpBtn.addEventListener('click', tryJump);

  function tryJump(){
    if(!running || paused) return;
    if(player.onGround){ player.vy = -14; player.onGround = false; soundJump(); }
  }

  // ---------- Main loop ----------
  function loop(ts){
    if(!running) return;
    if(paused){ lastTimestamp = ts; requestAnimationFrame(loop); return; }
    const dt = ts - lastTimestamp; lastTimestamp = ts;
    frames++; spawnTimer += dt;

    // dynamic difficulty & speed scaling with world level and current level
    const lvl = currentLevel();
    if(frames % 300 === 0) { baseSpeed += 0.03 + lvl*0.01; }
    speed = baseSpeed + worlds[currentWorld].enemySpeed * (0.4 + lvl*0.12);

    // spawn frequency depends on world & level
    const spawnInterval = Math.max(420 - currentWorld*30 - lvl*20, 200);
    if(spawnTimer > spawnInterval){
      spawnTimer = 0;
      spawnObstacle();
      if(Math.random() < 0.55) spawnCoin();
      if(Math.random() < 0.25 + currentWorld*0.05 + lvl*0.02) spawnEnemy();
      if(Math.random() < 0.12) spawnPowerup();
    }

    // input movement
    if(input.left) player.x -= (speed*0.95);
    if(input.right) player.x += (speed*0.95);
    player.x = Math.max(0, Math.min(player.x, canvas.width - player.width));

    // jump physics
    if(!player.onGround){ player.vy += 0.7; player.y += player.vy; if(player.y >= groundY){ player.y = groundY; player.vy = 0; player.onGround = true; } }

    // move entities
    obstacles.forEach(o => o.x -= speed);
    enemies.forEach(e => {
      // world-specific enemy movement
      if(currentWorld === 0){ // forest: slow chaser
        const dir = (player.x - e.x) > 0 ? 1 : -1; e.x += dir * (e.speed*0.5); e.x -= speed*0.25;
      } else if(currentWorld === 1){ // desert: fast straight-moving
        e.x -= speed * (1.1 + Math.random()*0.25);
      } else if(currentWorld === 2){ // snow: erratic
        e.x += Math.sin(e.x*0.02 + frames*0.04) * 0.6; e.x -= speed*0.9;
      } else { // space: aggressive chaser
        const dir = (player.x - e.x) > 0 ? 1 : -1; e.x += dir * (e.speed*1.1); e.x -= speed*0.18;
      }
    });
    coins.forEach(c => c.x -= speed);
    powerups.forEach(p => p.x -= speed);
    projectiles.forEach(pr => { pr.x += pr.vx; pr.y += pr.vy; });

    // boss update
    if(boss) updateBoss(dt);

    // cull off-screen
    obstacles = obstacles.filter(o => o.x + o.width > -40);
    enemies = enemies.filter(e => e.x + e.width > -30 && e.x < canvas.width + 100);
    coins = coins.filter(c => c.x > -40);
    powerups = powerups.filter(p => p.x > -40);
    projectiles = projectiles.filter(pr => pr.x > -50 && pr.x < canvas.width + 50 && pr.y > -50 && pr.y < canvas.height + 50);

    // collisions: obstacles
    for(let i=obstacles.length-1;i>=0;i--){
      const o = obstacles[i];
      if(rectsCollide(player,o)){
        if(activePower && activePower.type === 'shield'){ obstacles.splice(i,1); activePower.expires = Math.max(activePower.expires, performance.now() + 700); soundHit(); }
        else { obstacles.splice(i,1); takeDamage(); }
      }
    }
    // enemies collision
    for(let i=enemies.length-1;i>=0;i--){
      const e = enemies[i];
      if(rectsCollide(player,e)){
        if(activePower && activePower.type === 'shield'){ enemies.splice(i,1); soundHit(); }
        else { enemies.splice(i,1); takeDamage(); }
      }
    }
    // projectiles -> player
    for(let i=projectiles.length-1;i>=0;i--){
      const pr = projectiles[i];
      const prBox = { x: pr.x - pr.r, y: pr.y - pr.r, width: pr.r*2, height: pr.r*2 };
      if(rectsCollide(player, prBox)){
        projectiles.splice(i,1);
        if(activePower && activePower.type === 'shield'){ soundHit(); }
        else { takeDamage(); }
      }
    }
    // coins collision
    for(let i=coins.length-1;i>=0;i--){
      const c = coins[i];
      if(circleRectCollide(c.x, c.y, c.r, player)){
        coins.splice(i,1);
        const gained = (activePower && activePower.type === 'double') ? 20 : 10;
        score += gained;
        addProgress(gained * 0.6); // collecting contributes to level progress
        soundCoin();
      }
    }
    // powerups
    for(let i=powerups.length-1;i>=0;i--){
      const p = powerups[i];
      const box = { x:p.x-10, y:p.y-10, width:20, height:20 };
      if(rectsCollide(player, box)){ applyPower(p.type); powerups.splice(i,1); addProgress(40); }
    }
    // boss collision with player
    if(boss){
      // boss hurt by player's collision if shield? or player can't hurt boss directly — player must dodge projectiles and maybe jump on top
      // we make boss take damage if player collides from above (simple)
      if(rectsCollide(player, boss)){
        // if player is above the top of boss (landing), damage boss
        if(player.y + player.height <= boss.y + 18 && player.vy > 0){
          boss.hp -= 4;
          player.vy = -8;
          if(boss.hp <= 0){
            // boss defeated
            boss = null;
            score += 500;
            addProgress(400);
            saveHighscore();
          }
        } else {
          // player hit by boss
          takeDamage();
        }
      }
    }

    // active power timeout
    if(activePower && performance.now() > activePower.expires) clearPower();

    // level progress small passive gain
    addProgress(0.06 + currentWorld*0.01 + currentLevel()*0.01);

    // scoring passive
    score += 0.15 + currentWorld*0.03 + currentLevel()*0.02;

    // level reached max triggers boss spawn (ensured)
    if(currentLevel() >= MAX_LEVEL && !boss) spawnBossIfNeeded();

    // render & UI
    render();
    updateUI();

    requestAnimationFrame(loop);
  }

  // ---------- Boss functions ----------
  function spawnBossIfNeeded(){
    if(boss) return;
    const w = 160, h = 120;
    boss = { x: canvas.width + 80, y: groundY - (h - player.height), width:w, height:h, hp: 30 + currentWorld*20, phase:0, shootTimer: 0 };
  }

  function updateBoss(dt){
    if(!boss) return;
    boss.shootTimer -= dt;
    if(boss.shootTimer <= 0){
      boss.shootTimer = 1100 - currentWorld*80;
      // spawn aimed projectiles toward player (3)
      for(let i=0;i<3;i++){
        const angle = Math.atan2((player.y - boss.y), (player.x - boss.x)) + rand(-0.6,0.6);
        projectiles.push({ x: boss.x, y: boss.y + boss.height/2, vx: Math.cos(angle)*4.2, vy: Math.sin(angle)*4.2, r:6 });
      }
    }
    // boss float effect
    boss.y += Math.sin(frames*0.02) * 0.3;
    // boss auto moves slowly into scene
    if(boss.x > canvas.width - 320) boss.x -= 0.3 + currentWorld*0.05;
  }

  // ---------- Render ----------
  function createWorldBackground(idx){
    const cfg = worlds[idx];
    return `linear-gradient(180deg, ${cfg.bg1}, ${cfg.bg2})`;
  }

  function render(){
    // gradient background
    const cfg = worlds[currentWorld];
    ctx.fillStyle = cfg.bg1; ctx.fillRect(0,0,canvas.width,canvas.height);
    const g = ctx.createLinearGradient(0,0,0,canvas.height); g.addColorStop(0, cfg.bg1); g.addColorStop(1, cfg.bg2);
    ctx.fillStyle = g; ctx.fillRect(0,0,canvas.width,canvas.height);

    // decorative per world
    if(currentWorld===0){
      ctx.fillStyle = 'rgba(34,139,34,0.08)'; ctx.beginPath(); ctx.ellipse(240,420,320,88,0,0,Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(720,440,260,74,0,0,Math.PI*2); ctx.fill();
    } else if(currentWorld===1){
      ctx.fillStyle = 'rgba(210,180,140,0.08)'; ctx.beginPath(); ctx.ellipse(220,430,300,90,0,0,Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(660,450,240,70,0,0,Math.PI*2); ctx.fill();
    } else if(currentWorld===2){
      ctx.fillStyle = 'rgba(255,255,255,0.06)'; for(let i=0;i<12;i++){ ctx.beginPath(); ctx.arc(60+i*80, 40 + ((frames*0.5 + i*30)%260), 6,0,Math.PI*2); ctx.fill(); }
    } else {
      ctx.fillStyle = 'rgba(255,255,255,0.12)'; for(let i=0;i<40;i++){ ctx.fillRect((i*37)%canvas.width, (i*73+frames)%canvas.height, 2,2); }
    }

    // ground
    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(0, groundY + player.height, canvas.width, canvas.height - (groundY + player.height));

    // coins
    coins.forEach(c => { ctx.fillStyle = 'gold'; ctx.beginPath(); ctx.arc(c.x, c.y, c.r, 0, Math.PI*2); ctx.fill(); ctx.strokeStyle = '#b8860b'; ctx.stroke(); });

    // powerups
    powerups.forEach(p => {
      if(p.type === 'shield') ctx.fillStyle = '#61dafb';
      if(p.type === 'speed') ctx.fillStyle = '#ffa726';
      if(p.type === 'double') ctx.fillStyle = '#9c27b0';
      ctx.fillRect(p.x-10, p.y-10, 20, 20);
      ctx.fillStyle = '#fff'; ctx.font = '12px Arial'; ctx.fillText(p.type[0].toUpperCase(), p.x-4, p.y+5);
    });

    // obstacles
    ctx.fillStyle = '#222'; obstacles.forEach(o => ctx.fillRect(o.x, o.y, o.width, o.height));

    // enemies
    enemies.forEach(e => {
      ctx.fillStyle = cfg.enemyColor; ctx.fillRect(e.x, e.y - (e.height-player.height), e.width, e.height);
      ctx.fillStyle = '#fff'; ctx.fillRect(e.x + 8, e.y - (e.height-player.height) + 8, 6, 6);
    });

    // boss
    if(boss){
      ctx.fillStyle = '#333'; ctx.fillRect(boss.x, boss.y, boss.width, boss.height);
      ctx.fillStyle = '#fff'; ctx.font = '14px Arial'; ctx.fillText(`Boss HP: ${boss.hp}`, boss.x + 8, boss.y + 18);
    }

    // projectiles
    projectiles.forEach(pr => { ctx.fillStyle = '#ffcc00'; ctx.beginPath(); ctx.arc(pr.x, pr.y, pr.r, 0, Math.PI*2); ctx.fill(); });

    // player (animated bob)
    player.bob = Math.sin(frames*0.12) * 3;
    ctx.fillStyle = activePower && activePower.type === 'shield' ? '#77dd77' : '#ff5252';
    ctx.fillRect(player.x, player.y + player.bob, player.width, player.height);
    if(activePower && activePower.type === 'shield'){
      ctx.strokeStyle = '#4fc3f7'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(player.x + player.width/2, player.y + player.height/2 + player.bob, player.width, 0, Math.PI*2); ctx.stroke();
      ctx.lineWidth = 1;
    }
  }

  // ---------- Damage / Lives ----------
  function takeDamage(){
    soundHit();
    lives -= 1;
    if(lives <= 0){
      saveHighscore();
      running = false;
      stopWorldMusic();
      if(gameOverOverlay) gameOverOverlay.style.display = 'flex';
      if(finalScore) finalScore.textContent = `Your score: ${Math.floor(score)}`;
      if(highscoreEl) highscoreEl.textContent = highscore;
    } else {
      player.x = 50; player.y = groundY; player.vy = 0; player.onGround = true;
      // temporary shield
      activePower = { type:'shield', expires: performance.now() + 1200 };
    }
  }

  // ---------- Events ----------
  if(startBtn) startBtn.addEventListener('click', startGame);
  if(overlayStart) overlayStart.addEventListener('click', startGame);
  if(pauseBtn) pauseBtn.addEventListener('click', togglePause);
  if(stopBtn) stopBtn.addEventListener('click', ()=>{ running=false; saveHighscore(); stopWorldMusic(); if(menuOverlay) menuOverlay.style.display='flex'; });
  if(restartBtn) restartBtn.addEventListener('click', ()=>{ startGame(); if(gameOverOverlay) gameOverOverlay.style.display='none'; });
  if(closeOverlay) closeOverlay.addEventListener('click', ()=>{ if(gameOverOverlay) gameOverOverlay.style.display='none'; });

  worldBtns.forEach(btn => btn.addEventListener('click', ()=>{
    const idx = parseInt(btn.dataset.world) || 0;
    currentWorld = idx;
    // adjust base speed by world
    baseSpeed = 2 + worlds[currentWorld].enemySpeed;
    speed = baseSpeed;
    if(canvas) canvas.style.background = createWorldBackground(currentWorld);
    updateUI();
    if(running){ stopWorldMusic(); startWorldMusic(); }
  }));

  // mobile input handled earlier

  // ---------- Music control ----------
  function startWorldMusic(){ stopWorldMusic(); if(!audioCtx) return; startMusicImpl(); }
  function stopWorldMusic(){ if(musicInterval){ clearInterval(musicInterval); musicInterval = null; } }
  function startMusicImpl(){
    if(!audioCtx) return;
    const cfg = worlds[currentWorld].music;
    musicInterval = setInterval(()=>{
      if(cfg==='forest'){ beep(440,0.12,'sine',0.03); setTimeout(()=>beep(660,0.09,'sine',0.02),150); }
      if(cfg==='desert'){ beep(520,0.09,'triangle',0.035); setTimeout(()=>beep(780,0.06,'sine',0.02),180); }
      if(cfg==='snow'){ beep(360,0.12,'sine',0.03); setTimeout(()=>beep(480,0.06,'triangle',0.02),200); }
      if(cfg==='space'){ beep(280,0.14,'sawtooth',0.03); setTimeout(()=>beep(420,0.08,'sine',0.025),160); }
    }, 420);
  }

  // ---------- Level progress function ----------
  function getLevelThreshold(level){
    const base = [0, 150, 450, 900, 1600, 2600][level] || 2600;
    return Math.round(base * (1 + currentWorld*0.18));
  }

  function addProgress(amount){
    worldProgress[currentWorld] += amount;
    const lvl = currentLevel();
    const threshold = getLevelThreshold(lvl);
    if(worldProgress[currentWorld] >= threshold && lvl < MAX_LEVEL){
      worldLevels[currentWorld] = Math.min(MAX_LEVEL, lvl + 1);
      worldProgress[currentWorld] = 0;
      levelUpEffect();
      baseSpeed += 0.6; speed = baseSpeed + worlds[currentWorld].enemySpeed * 0.5;
    } else if(worldProgress[currentWorld] >= threshold && lvl >= MAX_LEVEL){
      spawnBossIfNeeded();
    }
  }

  function levelUpEffect(){
    if(levelNotice){ levelNotice.style.display = 'block'; setTimeout(()=> levelNotice.style.display = 'none', 1200); }
    soundLevelUp();
  }

  // ---------- Boss helpers already above ----------

  // ---------- Level/World initial arrays ----------
  // ensure arrays sized to number of worlds
  while(worldLevels.length < worlds.length) worldLevels.push(1);
  while(worldProgress.length < worlds.length) worldProgress.push(0);

  // ---------- initial UI ----------
  if(highscoreEl) highscoreEl.textContent = highscore;
  if(canvas) canvas.style.background = createWorldBackground(currentWorld);
  if(menuOverlay) menuOverlay.style.display = 'flex';
  if(gameOverOverlay) gameOverOverlay.style.display = 'none';
  updateUI();

  // ---------- expose debug API ----------
  window.pa_adv = { start: startGame, stop: stopGame, togglePause };

  // ---------- helper to save highscore ----------
  function saveHighscore(){ if(Math.floor(score) > highscore){ highscore = Math.floor(score); localStorage.setItem('pa_highscore', highscore); } }

  // ---------- done ----------
});
