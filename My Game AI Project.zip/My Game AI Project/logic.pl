% ---- GAME LEVEL LOGIC -----

% enemy_speed(Level, Speed)
enemy_speed(1, 2).
enemy_speed(2, 4).
enemy_speed(3, 6).

% unlock_next_level(CurrentLevel, NextLevel)
unlock_next_level(1, 2).
unlock_next_level(2, 3).

% Check if player is fast enough to level up
can_level_up(Score, Level) :-
    Score > 500,
    Level < 3.
