const express = require("express");
const app = express();
const pl = require("tau-prolog");
require("tau-prolog/modules/lists.js");

const fs = require("fs");

// Load Prolog file
let session = pl.create(10000);
let prologCode = fs.readFileSync("logic.pl", "utf8");
session.consult(prologCode);

// Serve public folder
app.use(express.static("public"));

app.get("/get-speed", (req, res) => {
    let level = req.query.level;

    session.query(`enemy_speed(${level}, Speed).`);
    session.answer(ans => {
        let speed = ans.lookup("Speed");
        res.json({ speed: parseInt(speed) });
    });
});

app.get("/can-level-up", (req, res) => {
    let score = req.query.score;
    let level = req.query.level;

    session.query(`can_level_up(${score}, ${level}).`);
    session.answer(ans => {
        res.json({ result: ans !== false });
    });
});

app.listen(3000, () => console.log("Server running on port 3000"));
